
# AI Secretary MVP

本文件夹用于交给 Codex / Cursor / AI 开发工具生成项目。

包含：
- 产品需求文档
- 技术架构
- 数据库设计
- API 设计
- AI Prompt

推荐生成顺序：
1. Flutter 前端
2. FastAPI 后端
3. Supabase 数据库
4. AI 接口
5. Push 提醒
