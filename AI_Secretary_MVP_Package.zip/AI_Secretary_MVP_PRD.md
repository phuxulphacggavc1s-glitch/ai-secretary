
# AI Secretary MVP 开发文档

## 项目定位
一个支持手机 + 电脑同步的 AI 生活/工作秘书系统。

用户只需要说一句话：
- “明天下午提醒我给客户报价”
- “月底提醒我交房租”
- “记一下直播优化方案”

系统自动完成：
- 时间解析
- 分类
- 提醒
- 云同步
- AI 总结

---

# MVP 功能

## 1. 登录系统
支持：
- 手机号登录
- 微信登录（后期）

目的：
- 数据同步
- 换手机不丢数据

---

## 2. 快速记录
支持：
- 文字输入
- 后期支持语音输入

AI 自动解析：
- 时间
- 分类
- 内容

示例：

输入：
“明天下午提醒我给客户报价”

输出：
{
  "content": "给客户报价",
  "category": "工作",
  "remind_time": "2026-06-03 15:00"
}

---

## 3. 提醒系统

支持：
- 手机 Push
- Web 通知

提醒内容：
“你有一个待办：给客户报价”

---

## 4. 待办列表

分类：
- 全部
- 工作
- 生活
- 灵感
- 财务
- 已完成

支持：
- 搜索
- 修改
- 删除
- 完成状态

---

## 5. AI 每日总结

每天晚上自动生成：

- 今日完成事项
- 未完成事项
- 明日重点

---

# 技术架构

Flutter（手机/Web）
↓
FastAPI（后端 API）
↓
Supabase（数据库）
↓
OpenAI / DeepSeek（AI能力）

---

# 推荐技术栈

## 前端
Flutter

## 后端
Python FastAPI

## 数据库
Supabase

## AI
OpenAI API / DeepSeek API

## Push
Firebase Push Notification

---

# 数据库设计

## users

```sql
create table users (
  id uuid primary key,
  phone text,
  nickname text,
  created_at timestamp default now()
);
```

## tasks

```sql
create table tasks (
  id uuid primary key default gen_random_uuid(),

  user_id uuid,

  content text not null,

  category text,

  remind_time timestamp,

  status text default 'pending',

  priority int default 1,

  ai_summary text,

  created_at timestamp default now(),

  updated_at timestamp default now()
);
```

## daily_reports

```sql
create table daily_reports (
  id uuid primary key default gen_random_uuid(),

  user_id uuid,

  report_date date,

  content text,

  created_at timestamp default now()
);
```

---

# API 设计

## 创建任务

POST /tasks/create

请求：

```json
{
  "content": "明天下午提醒我给客户报价"
}
```

返回：

```json
{
  "success": true,
  "task": {
    "id": "123",
    "content": "给客户报价",
    "category": "工作",
    "remind_time": "2026-06-03 15:00"
  }
}
```

---

## 获取任务列表

GET /tasks/list

---

## 完成任务

POST /tasks/complete

---

## 删除任务

POST /tasks/delete

---

## AI 日报

GET /reports/daily

---

# AI Prompt

系统 Prompt：

```text
你是一个生活与工作秘书。

你的任务：
1. 识别用户待办事项
2. 自动分类
3. 提取时间
4. 返回JSON

分类：
- 工作
- 生活
- 灵感
- 财务
- 学习

返回格式：
{
  "content":"",
  "category":"",
  "remind_time":""
}
```

---

# Flutter 页面结构

lib/
 ├── pages/
 │    ├── home/
 │    ├── tasks/
 │    ├── report/
 │    └── profile/
 │
 ├── services/
 │    ├── api.dart
 │    └── ai.dart
 │
 ├── models/
 │
 ├── widgets/
 │
 └── main.dart

---

# 首页 UI

--------------------------------
 AI秘书
--------------------------------

[输入框....................]
         [发送]

最近记录：

- 明天给客户报价
- 周五交房租
- 直播间优化方案

--------------------------------

---

# 开发顺序

## 第一阶段
- 登录
- 创建待办
- 查看待办
- 提醒
- 云同步

## 第二阶段
- AI 分类
- AI 时间解析

## 第三阶段
- AI 日报
- AI 主动提醒

---

# 产品核心方向

不是传统待办工具。

而是：

AI 第二大脑 + AI 生活秘书。

未来方向：
- AI 主动提醒
- AI 工作规划
- AI 周报
- AI 灵感整理
- AI 时间安排
- AI 个人记忆系统
